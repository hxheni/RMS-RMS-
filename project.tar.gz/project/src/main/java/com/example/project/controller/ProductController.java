package com.example.project.controller;


import com.example.project.model.Product;
import com.example.project.model.Waiter;
import com.example.project.service.ProductService;
import com.example.project.service.WaiterService;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;
@RestController
@RequestMapping("/api/data/product")
public class ProductController {


    private ProductService service;

    public ProductController(ProductService service){
        this.service = service;

    }

    @GetMapping("/{id}")
    public Product getProductById(@PathVariable Integer id){
        return service.getById(id).get();
    }

    @GetMapping("/{name}")
    public Product getProductByName(@PathVariable String name){
        return service.getByProduct_name(name).get();
    }

    @PostMapping
    public Product addProduct(@RequestBody Product product){

        return service.save(product);
    }


}
