package com.example.project.controller;

import com.example.project.model.Menu;
import com.example.project.model.Product;
import com.example.project.service.MenuService;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

@RestController
@RequestMapping("/api/data/menu")
public class MenuController {


    private MenuService service;

    public MenuController(MenuService service){
        this.service = service;

    }

    @GetMapping("/{id}")
    public Optional<Menu> getMenuById(@PathVariable Integer id){
        return service.getFirstById(id);
    }


    @PostMapping
    public Menu addMenu(@RequestBody Menu menu){

        return service.save(menu);
    }
}
