package com.example.project.service;

import com.example.project.dao.MenuRepository;
import com.example.project.dao.WaiterRepository;
import com.example.project.model.Menu;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class MenuService {
    private MenuRepository repository;

    public MenuService(MenuRepository repository){
        this.repository = repository;
    }

    public Optional<Menu> getFirstById(Integer id){
        return repository.getFirstById(id);
    }
//    public Menu getByMenu_item(String menu_item){
//        return repository.getByMenu_item(menu_item);
//    }
    public Iterable<Menu> findAll(){
        return repository.findAll();
    }


    public void deleteById(Integer id){
        repository.deleteById(id);
    }

    public Menu save(Menu menu){
        return repository.save(menu);
    }
}
