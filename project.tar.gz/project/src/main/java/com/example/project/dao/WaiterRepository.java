package com.example.project.dao;

import com.example.project.model.Waiter;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface WaiterRepository extends CrudRepository<Waiter, Integer> {
    Optional<Waiter> getById(Integer id);
    Optional<Waiter> getByUsername(String userName);
//    Optional<User> getAll();

    void deleteById(Integer id);


    Waiter save(Waiter waiter);
}