package com.example.project.service;

import com.example.project.dao.ProductRepository;

import com.example.project.model.Product;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class ProductService {
    private ProductRepository repository;

    public ProductService(ProductRepository repository){
        this.repository = repository;
    }

    public Optional<Product> getById(Integer id){
        return repository.getById(id);
    }

    public Optional<Product> getByProduct_name(String name){
        return repository.getByName(name);
    }

    public Iterable<Product> findAll(){
        return repository.findAll();
    }

    public void deleteById(Integer id){
        repository.deleteById(id);
    }
    public Product save(Product product){
        return repository.save(product);
    }
}
