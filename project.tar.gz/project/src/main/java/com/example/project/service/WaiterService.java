package com.example.project.service;

import com.example.project.dao.WaiterRepository;
import com.example.project.model.Waiter;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class WaiterService{
    private WaiterRepository repository;

    public WaiterService(WaiterRepository repository){
        this.repository = repository;
    }

    public Optional<Waiter> getById(Integer id) {
        return repository.getById(id);
    }


    public Optional<Waiter> getByUserName(String name) {
        return repository.getByUsername(name);
    }




    public void deleteById(Integer id) {
        repository.deleteById(id);

    }


    public Waiter save(Waiter waiter) {
        System.out.println(waiter.toString());
       return repository.save(waiter);
    }
}
