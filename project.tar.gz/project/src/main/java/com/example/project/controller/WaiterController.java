package com.example.project.controller;

import com.example.project.model.Waiter;
import com.example.project.service.WaiterService;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;
@RestController
@RequestMapping("api/data/waiter")
public class WaiterController {


    private WaiterService service;

    public WaiterController(WaiterService service){
        this.service = service;

    }

    @GetMapping(value = "/{id}")
    public Optional<Waiter> getWaiterById(@PathVariable Integer id){
        return service.getById(id);
    }

    @PostMapping
    public Waiter addWaiter(@RequestBody Waiter waiter){

        return service.save(waiter);
    }


}
