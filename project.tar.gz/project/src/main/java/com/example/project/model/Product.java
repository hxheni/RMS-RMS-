package com.example.project.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import java.util.Objects;

@Entity
public class Product{

    @Id
    @GeneratedValue(strategy= GenerationType.AUTO)
    private Integer id;

    private String name;

    private Double product_cost;

    private Double total_amount_available;

    private Double amount_used;

    private Double amount_left;

    public Product() {
    }

    public String getName() {
        return name;
    }

    public void setProduct_name(String name) {
        this.name = name;
    }

    public Double getProduct_cost() {
        return product_cost;
    }

    public void setProduct_cost(Double product_cost) {
        this.product_cost = product_cost;
    }

    public Double getTotal_amount_available() {
        return total_amount_available;
    }

    public void setTotal_amount_available(Double total_amount_available) {
        this.total_amount_available = total_amount_available;
    }

    public Double getAmount_used() {
        return amount_used;
    }

    public void setAmount_used(Double amount_used) {
        this.amount_used = amount_used;
    }

    public Double getAmount_left() {
        return amount_left;
    }

    public void setAmount_left(Double amount_left) {
        this.amount_left = amount_left;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Product product = (Product) o;
        return Objects.equals(id, product.id);
    }

    @Override
    public int hashCode() {

        return Objects.hash(id);
    }
}
