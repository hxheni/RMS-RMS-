package com.example.project.dao;


import com.example.project.model.Menu;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;


import java.util.Optional;

@Repository
public interface MenuRepository extends CrudRepository<Menu,Integer>{
    public Optional<Menu> getFirstById(Integer id);

//    public Menu getByMenu_item(String menu_item);




    @Override
    public void deleteById(Integer id);

    @Override
    public <S extends Menu> S save(S s);
}
